#!/bin/bash

# Oracle Cloud (Ubuntu ARM) 環境構築スクリプト

set -e

echo "=== [1/5] システムの更新と必須パッケージのインストール ==="
sudo apt update && sudo apt upgrade -y
sudo apt install -y build-essential libreadline-dev libssl-dev zlib1g-dev git curl wget unzip

echo "=== [2/5] Node.js (v20) のインストール ==="
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

echo "=== [3/5] PM2 (プロセス管理者) のインストール ==="
sudo npm install -g pm2

echo "=== [4/5] SoftEther VPN Client のビルドとインストール ==="
# 注意: SoftEtherのStable版をソースからビルド
cd /tmp
git clone --recursive https://github.com/SoftEtherVPN/SoftEtherVPN_Stable.git
cd SoftEtherVPN_Stable
# オプション1: Standard Linux (x64/ARM)
# インタラクティブ入力を避けるために make 時に回答が必要な場合があるため、簡易版を使用
# make が通らない場合は vpnclient バイナリを直接持ってくる方が安全な場合もある
# ここでは標準的な手順を示す
./configure
make
sudo make install

echo "=== [5/5] Playwright 依存関係のインストール ==="
# 共通ライブラリのインストール
sudo npx playwright install-deps

echo "=== セットアップ完了 ==="
echo "次にプロジェクトを git clone またはファイル転送してください。"
